  GLinfo2.zip
***************
 (Version 2.5)

GLinfo is a utility that gathers information about your OpenGL drivers. GLinfo
can detect your driver version, the list of OpenGL extensions, and a bunch of
implementation-specific values such as the maximum texture resolution.

After all this information has been presented to you, you can choose to save a
report in HTML format, for later reference, or you can submit the information to
Delphi3D's online Hardware Registry. The hardware registry is a searchable
database that allows you to see the GLinfo reports of 3D cards other than yours.
You can visit the registry at http://www.delphi3d.net/hardware.

The hardware registry is meant to give you an idea of the level of OpenGL
functionality of the variety of 3D cards that are out there. You can, for
example, search the registry for all card/driver combos that support
multitexturing. The registry is mostly intended to be a quick reference for
developers, who want to know how many cards will be able to run their apps if
they use a certain extension.

GLinfo should not require any instructions to use. Just browse the information
on-screen, or go to the "Reports" page to save or submit the information.
Submission is fully automatic. Note that GLinfo will not transfer any
information other than what it displays on the screen or saves to its reports.
No extra information is taken from your PC. Also note that in the extension
lists, clicking the name of an extension will automagically take you to that
extension's specification on the web.

Keep in mind that the hardware registry is of no use without your help! If your
3D card/driver combo is not yet listed on the site, please take some time to
submit a report. Thanks!

  Tom Nuydens(tom@delphi3d.net)
